<?php
/**
 * Created by PhpStorm.
 * User: nana
 * Date: 2016/6/23
 * Time: 10:12
 */
echo json_encode('{"code":1}');